QUESTION:
A ship crashed into a reef and is sinking. Now the entire crew must be evacuated. All n crew members have already lined up in a row (for convenience let's label them all from left to right with positive integers from 1 to n) and are waiting for further instructions. However, one should evacuate the crew properly, in a strict order. Specifically:

The first crew members to leave the ship are rats. Then, women and children (both groups have the same priority) leave the ship. After that, all men are evacuated from the ship. The captain leaves the sinking ship last.

If we cannot determine exactly who should leave the ship first for any two members of the crew by the rules from the previous paragraph, then the one who stands to the left in the line leaves the ship first (or in other words, the one whose number in the line is less).

For each crew member, we know his status as a crew member, and also his name. All crew members have different names. Write a program to determine the order in which to evacuate the crew.



INPUT & OUTPUT FORMAT:
The first input contains an integer n, which is the number of people in the crew (1 ≤ n ≤ 100).
The next 'n' lines contain two words — the name of the crew member, and his status on the ship.
The words are separated by exactly one space. There are no other spaces in the line.
The names consist of letters, the first letter is uppercase, the rest are lowercase. The length of any name is from 1 to 10 characters. The status can have the following values: rat for a rat, woman for a woman, child for a child, man for a man, captain for the captain. The crew contains exactly one captain.
The output displays n lines. The i-th of them should contain the name of the crew member who must be the i-th one to leave the ship.
SAMPLE INPUT & OUTPUT:

Enter the number of people in the crew 
 6 
Enter the name of the crew member and his status on the ship 
Jack captain
Alice woman
Charlie man
Teddy rat
Bob child
Julie woman 
Order to evacuate the crew 
Teddy 
Alice 
Bob 
Julie 
Charlie 
Jack

Code:

