Write a program to count the number of vowels in the given string:

Input Format:

Input consist of 1 string.
Sample Input & Output:

hello

Number of vowels: 2

Code:

import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        Scanner sc  = new Scanner(System.in);
        String a = sc.nextLine();
        int vc = 0;
        for(int i=0;i<a.length();i++){
            char ch = Character.toLowerCase(a.charAt(i));
            if(ch== 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u'){
                vc++;
            }
        } System.out.println("Number of vowels : "+vc);
    }
}