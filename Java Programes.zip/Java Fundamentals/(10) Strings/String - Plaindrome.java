Write a program to find whether the given string is palindrome or not without using string library functions:


Input Format:

Input consist of 1 string.
If the given string is a Palindrome display “Palindrome”, else display “Not a Palindrome”.
Sample Input & Output:
computer
Not a Palindrome

Code:

import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String r = "";
        for(int i=s.length()-1;i>=0;i--){
            r=r+s.charAt(i);
        }
        String check = (s.equals(r))? "Palindrome" : "Not a Palindrome";
        System.out.println(check);
    }
}