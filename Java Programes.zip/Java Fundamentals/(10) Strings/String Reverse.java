Write a  program to find the reverse of the given without string using string library functions:

Input Format:

Input consist of 1 string.
Sample Input & Output:

hello

The reversed String is olleh

Code:

import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String a = sc.nextLine();
        int i;
        System.out.print("The reversed string is ");
        for(i=a.length()-1;i>=0;i--){
            char ch = a.charAt(i);
            System.out.print(ch);
        }
    }
}