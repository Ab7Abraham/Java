There were two best friends. They had a fight between them and they were not talked with each other. Help those two peoples to join again and let them enjoyed. Find the concatenation of given two strings using string library functions:

Input Format:

Input consist of 2 string.
Sample Input & Output:

Hello

all

Helloall

Code:

import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String a = sc.nextLine();
        String b = sc.nextLine();
        System.out.println(a+b);
    }
}