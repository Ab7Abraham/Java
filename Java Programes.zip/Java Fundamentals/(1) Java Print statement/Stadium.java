// MECON LIMITED was a public sector undertaking firm under the ministry of steel where Dhoni's father had worked for. It was the stadium where MS Dhoni grew up playing.

//The Chairman of MECON decided to renovate and improvise the facilities in the stadium and to place a NEON display board at the entry of the stadium that carried the Stadium's name as "MECON Stadium".

//Write a program to display the Stadium name in different lines.

//Input Format:
//There is no input

//Output Format:
//Print the name "MECON Stadium" in different lines.

//SAMPLE OUTPUT:
//MECON
//Stadium

Code:
public class Main
{
    public static void main(String[] args)
    {
        System.out.println("MECON");
        System.out.println("Stadium");
    }
}
