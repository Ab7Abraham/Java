/**
Write a java program to rotate a matrix n times in clockwise and anti-clockwise direction using inheritance.
Create a base class Clock.
From this extends a child class Clockwise and Anticlockwise.
Both these child classes should contain the method rotate().

Input Format
The first line contains the number of rows
The second line contains the number of columns
The third lines contain the matrix as input rows and columns with space as separator between each item in the matrix
Then the last line contains the number of rotations to be performed

Output Format
Print the matrix after performing the n number of clockwise and anticlockwise rotations

Constraints
0 < Row <=10
0 < Column <=10
0 < Number Of Rotations <=10

Sample Input
3
3
1 2 3
4 5 6
7 8 9
1
Sample Output
Clockwise 
4 1 2 
7 5 3 
8 9 6 
Anti clockwise 
2 3 6 
1 5 9 
4 7 8 
Sample Input
4
4
1 2 3 4
5 6 7 8
9 10 11 12
13 14 15 16
3
Sample Output
Clockwise 
13 9 5 1 
14 7 11 2 
15 6 10 3 
16 12 8 4 
Anti clockwise 
4 8 12 16 
3 10 6 15 
2 11 7 14 
1 5 9 13 
 */

 Code:

 