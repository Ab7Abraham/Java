/**
Write a java program to implement an abstract class "Marks" with a method "getPercentage()".

Then, create a class called "A" which extends "Marks" and has three attributes named "Marks1", "Marks2", and "Marks3". This class should also have a method named "getPercentage()" that calculates and prints the percentage of the student.

Similarly, create another class called "B" that extends "Marks" and has four attributes named "Marks1", "Marks2", "Marks3", and "Marks4". This class should also have a method named "getPercentage()" that calculates and prints the percentage of the student.

Please note that each mark is out of 100, and you should find the percentage for two students (Student A and Student B) and round off the output to two decimal places.

Input Format
The first line of the input consists of three integers, i.e., the marks scored by student A.
The second line of the input consists of four integers, i.e., the marks scored by student B.

Output Format
The first line prints the percentage of A.
The second line prints the percentage of B.

Sample Input
95 85 75
85 77 92 93

Sample Output
85.00
86.75 
*/

Code:
