/**
Write a java program that creates an abstract class called "Shape". This class should have the following methods:

abstract void rectangleArea();
abstract void squareArea();
abstract void circleArea();

Then, create a class called "Area" that extends the "Shape" class. This class should calculate and print the area of all shapes.
Finally, create a Main class that gets the inputs and passes them to the appropriate methods.

Input Format
The first line of the input consists of the length and breadth.
The second line consists of the side.
The third line consists of the radius.

Output Format
The output prints the area of a rectangle, square, and circle.


Sample Input
10 20
4
5
Sample Output
200
16
78.54
Sample Input
40 20
4
5

Sample Output
800
16
78.54 */

Code:
