/**
Write a computer program that creates an abstract class called "First". This class should have three abstract methods:
input(), add(), result()
Then, create at least one subclass that extends the "First" class. This subclass should implement the three abstract methods.
Finally, create an object for each subclass and call their respective methods.

Input Format
The input consists of two integers.

Output Format
The output consists of the sum of two numbers.

Sample Input
10
20

Sample Output
30

Sample Input
500
1000

Sample Output
1500 */

Code:
