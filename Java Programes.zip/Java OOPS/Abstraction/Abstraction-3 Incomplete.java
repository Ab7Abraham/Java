/**
Write a program in Java that finds the addition, subtraction, multiplication, and division of two complex numbers using inheritance.

Your program should create an abstract class called "Complex". This class should have methods for performing arithmetic operations on complex numbers.

Then, create four child classes called "Addition", "Subtraction", "Multiplication", and "Division". These child classes should extend the "Complex" class and implement the methods for their respective operations.

Input Format
Input consists of four double-type variables, which denote the real and imaginary parts of the first and second complex numbers, respectively.

Output Format
The output consists of the addition, subtraction, multiplication, and division of the two complex numbers.

Sample Input
2 6
4 2

Sample Output

Addition:
	6.0000 +8.0000 i
Subtraction:
	-2.0000 +4.0000 i
Multiplication:
	-4.0000 +28.0000 i
Division:
	1.0000 +1.0000 i
Sample Input
0 0
0 0

Sample Output

Addition:
	0.0000 +0.0000 i
Subtraction:
	0.0000 +0.0000 i
Multiplication:
	0.0000 +0.0000 i
Division:
	NaN NaN i */

    Code:
    