/**
Create an abstract class 'Bank' with an abstract method 'getBalance'. Amounts are deposited in banks A, B and C respectively. 'BankA', 'BankB', and 'BankC' are subclasses of class 'Bank', each having a method named 'getBalance'. Call this method by creating an object of each of the three classes.

Input Format
The Input consists of three integers.

Output Format
Refer to the sample input and output

Sample Input
100
200
300

Sample Output
Deposited Balance is = 100
Deposited Balance is = 200
Deposited Balance is = 300

Sample Input
0
10
20

Sample Output
Deposited Balance is = 0
Deposited Balance is = 10
Deposited Balance is = 20 */
Code:
