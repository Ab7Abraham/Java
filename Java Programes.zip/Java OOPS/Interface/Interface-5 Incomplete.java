/**
Create a Notification interface which has three methods

1.      notificationBySms()

2.      notificationByEmail()

3.      notificationByCourier()﻿


Create two class as Icici and Hdfc which implements Notification.
Create a main class which gets input from user and display suitable notification. Refer sample input and output.

Input Format
First line of the input consists of bank code (1 for ICICI and 2 for HDFC)
Second line of the input consists of notification type (1 for SMS, 2 for Email and 3 for Courier)

Output Format
The output prints the bank name with notification type.

Sample Input
1
2

Sample Output
ICICI - Notification by Email

Sample Input
2
3

Sample Output
HDFC - Notification by Courier

Sample Input
3
1

Sample Output
Invalid Input

 */

 Code:

 