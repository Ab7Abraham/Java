/**
Write a java program to count the minimum number of front moves required to sort an array.
Your program should create an interface that declares a method. The class should implement this interface.

Input Format
The first line of the input consists of an integer.
The second line of the input consists of an integer.

Output Format
The output of your program should be an integer representing the minimum number of front moves required to sort the array.

Constraints
N- integer type(Natural numbers)

Sample Input
5
2 3 1 4 5

Sample Output
1

Sample Input
7
5 6 3 2 4 1 7

Sample Output
4 */

Code:

