/**
Write a program to move all the uppercase characters to the end of the string.
Note: Create an interface name Case with a method, and the main class should define the interface method.

Input Format
The first line of the input consists of a string.

Output Format
Display the output as uppercase characters at the end of the string.

Sample Input
REasonBehInd

Sample Output
asonehndREBI

Sample Input
donald

Sample Output
donald */

Code:

