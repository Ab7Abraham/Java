/**
Write a java program to create an interface called "ShapeCalculator" that has a method called "calc(int n)".

Then, create two classes called "Square" and "Circle" that implement the "ShapeCalculator" interface and implement the "calc(int n)" method.

Your program should calculate the area and perimeter of both squares and circles.

Input Format
The input to your program will be a single integer that represents the side of the square and the radius of the circle.

Output Format
The output of your program should be the area and perimeter of each shape.
The output should be displayed in two lines.
The first line should contain the area and perimeter of the square separated by a space, and the second line should contain the details of the circle in a similar format.

 Please note that the details of the square should be calculated using integer type while the details of the circle should be calculated using double type

Sample Input
8

Sample Output
64 32
200.96 50.24

Sample Input
7
Sample Output
49 28
153.86 43.96

 */

 Code:

 