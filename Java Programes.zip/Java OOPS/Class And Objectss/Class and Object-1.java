/**
 * Write a Java program that prints a welcome message and a hello message using two different classes Message and Hello, each with a default constructor that outputs a specific message.
 *
 * Input Format:
 * No console Input.
 *
 * Output Format:
 * The Output Should display the Welcome Message
 *
 * Sample 1 Input:
 * No input values.
 *
 * Sample 1 Output:
 * Welcome Hello
 */

Code:
class letter{
    public static void execute(){
        System.out.println("Welcome hello");
    }

}
class Main
{
    public static void main(String[] args)
    {

        letter l = new letter();
        l.execute();
    }
}
