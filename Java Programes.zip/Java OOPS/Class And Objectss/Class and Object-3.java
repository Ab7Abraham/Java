/**
Write a Java Program to Create a Class named Player with the following member variables/attributes. Create another Class called Main and write a main method to get the player details in a string separated by a comma. Use String. Split() function to display the details.

Sample 1 Input:
MS Dhoni,India,Wicket Keeper 

Sample 1 Output:
Player Details
Player Name: MS Dhoni
Country Name: India
Skill: Wicket Keeper 

Sample 2 Input:
Virat Kholi,India,Batsman 

Sample 2 Output:
Player Details
Player Name: Virat Kholi
Country Name: India
Skill: Batsman
 */

 Code:
 import java.util.Scanner;
class Subject
{
    Scanner sc = new Scanner(System.in);
    String a = sc.nextLine();
    String b = a.split(",")[0];
    String c = a.split(",")[1];
    String d = a.split(",")[2];
}
class Main{
    public static void main(String[] args){
    Subject sj = new Subject();
    System.out.println("player Details");
    System.out.println("Player Name: "+sj.b);
    System.out.println("Country Name: "+sj.c);
    System.out.println("Skill: "+sj.d);
}
}